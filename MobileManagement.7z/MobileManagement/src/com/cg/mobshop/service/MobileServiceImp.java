package com.cg.mobshop.service;

import java.util.HashMap;
import java.util.List;
import com.cg.mobshop.dao.MobileDao;
import com.cg.mobshop.dao.MobileDaoImp;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImp implements MobileService {
MobileDao md=new MobileDaoImp();
	@Override
	public HashMap<Integer, Mobiles> getMobileList() {
		
		HashMap<Integer,Mobiles>m1=md.getMobileList();
		return m1;
	}

	@Override
	public HashMap<Integer, Mobiles> deletemobile(int id) {
		 HashMap<Integer,Mobiles> hs=md.deletemobile(id);
			return hs;
		
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		
		return null;
	}

	@Override
	public HashMap<Integer, Mobiles> fetchAll() {
		HashMap<Integer, Mobiles> hs=md.fetchAll();
		return hs;
		
	}

	@Override
	public List<Mobiles> sortByName() {
		List<Mobiles> e=md.sortByName();
		return e;
	}

	@Override
	public List<Mobiles> sortByPrice() {
	
		List<Mobiles> e1=md.sortByPrice();
		return e1;
	}

	@Override
	public List<Mobiles> sortByQuantity() {
		List<Mobiles> e1=md.sortByPrice();
		return e1;
	}

}
