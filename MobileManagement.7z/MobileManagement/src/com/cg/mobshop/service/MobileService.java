package com.cg.mobshop.service;

import java.util.HashMap;
import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {
	public HashMap<Integer, Mobiles> getMobileList();
	public HashMap<Integer, Mobiles> deletemobile(int id);
	public List<Mobiles> SortList(int criteria);
	public HashMap<Integer, Mobiles> fetchAll();
	public List<Mobiles> sortByName();
	public List<Mobiles> sortByPrice();
	public List<Mobiles> sortByQuantity();
}
