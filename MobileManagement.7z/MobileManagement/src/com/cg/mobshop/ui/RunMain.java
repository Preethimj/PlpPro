package com.cg.mobshop.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImp;
public class RunMain {
	static Scanner sc =null;
	static MobileService serv = null;
	

	public static void main(String[] args) throws MobileException {
	
		sc = new Scanner(System.in);
		serv=new MobileServiceImp();
		
		int choice=0;
		System.out.println("Welcome to Mobile Shopee");
		while(true){
			System.out.println("\nEnter Your Choice");
			System.out.println("press 1 to Display all the mobiles from collection");
			System.out.println("press 2 to delete mobile record from mobile list");
			System.out.println("press 3 to Sort the Mobile Details based on criteria");
			
			choice = sc.nextInt();
			switch (choice) {
			
			case 1:
				fetchAll();
				break;
					
			case 2:
				deletemobile();
				break;
			case 3:
				sortmobile();
				break;
				
			default:
				break;
			}
		
		}		
}


	


	private static void sortmobile() {
		int choice=0;
		System.out.println("Select Sorting Criteria");
		while(true){
			System.out.println("\nEnter Your Choice");
			System.out.println("1.Mobile Name");
			System.out.println("2.Mobile Price");
			System.out.println("3.Mobile Quantity");
			
			choice = sc.nextInt();
			switch (choice) {
			
			case 1:
				sortByName();
				break;
					
			case 2:
				sortByPrice();
				break;
			case 3:
				sortByQuantity();
				break;
				
			default:
				System.exit(0);
				break;
			}
		
		}		
		
	}





	private static void sortByQuantity() {
		List<Mobiles> l=serv.sortByQuantity();
		System.out.println("sorting of mobile model by Quantity"+l);
		
	}





	private static void sortByPrice() {
		List<Mobiles> l=serv.sortByPrice();
		System.out.println("sorting of mobile model by price"+l);
		
	}





	private static void sortByName() {
		List<Mobiles> l=serv.sortByName();
		
		System.out.println("sorting of mobile by name");
				Iterator<Mobiles> i=l.iterator();
				while(i.hasNext())
					{
					System.out.println(i.next());
					}
				
		
	}





	private static void fetchAll() {
	
			 HashMap<Integer, Mobiles> hs=serv.fetchAll();
			 Set set = hs.entrySet();
		      Iterator iterator = set.iterator();
		      while(iterator.hasNext()) {
		         Map.Entry e = (Map.Entry)iterator.next();
		         System.out.print("Mobile "+ e.getKey() + " & Value is: ");
		         System.out.println(e.getValue());
		      }
		
	}

private static void deletemobile() {
		 System.out.println("enter mobileid");
		 int id=sc.nextInt();
		 System.out.println("The mobile record is deleted ");
		 System.out.println("The remaining record in collection are...");
		 HashMap<Integer, Mobiles> hs=serv.fetchAll();
		
	if(hs.containsKey(id))
	{
		 HashMap<Integer, Mobiles> hs1=serv.deletemobile(id);
		 System.out.println(hs1);
	}
	
	}


}