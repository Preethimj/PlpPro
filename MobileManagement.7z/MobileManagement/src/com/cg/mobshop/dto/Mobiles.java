package com.cg.mobshop.dto;

import java.util.Comparator;





public class Mobiles implements Comparable<Mobiles> {
private int mobileId;
private String name;
private int price;
private int quantity;
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
@Override
public String toString() {
	return "Mobiles [mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
}
public Mobiles(int mobileId, String name, int price, int quantity) {
	super();
	this.mobileId = mobileId;
	this.name = name;
	this.price = price;
	this.quantity = quantity;
}
public Mobiles() {
	super();
	// TODO Auto-generated constructor stub
}
public static Comparator<Mobiles> getcompname()
{
	Comparator<Mobiles> comp=new Comparator<Mobiles>() {
@Override
public int compare(Mobiles o1,Mobiles o2) {
	// TODO Auto-generated method stub
	return  o1.name.compareTo(o2.name);
}
	};
	return comp;
}

public int compareTo(Mobiles a) {
	return (int)(this.price-a.price);
}

public int compareTo1(Mobiles a) {
	return (int)(this.quantity-a.quantity);
}
}
