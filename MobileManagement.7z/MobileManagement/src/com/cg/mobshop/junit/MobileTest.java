package com.cg.mobshop.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MobileTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
