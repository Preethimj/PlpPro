package com.cg.mobshop.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileDao {
	public HashMap<Integer, Mobiles> getMobileList();
public HashMap<Integer, Mobiles> deletemobile(int mobcode);
public List<Mobiles> SortList(int criteria);
public HashMap<Integer, Mobiles> fetchAll();
public List<Mobiles> sortByName();
public List<Mobiles> sortByPrice();
public List<Mobiles> sortByQuantity();
}
