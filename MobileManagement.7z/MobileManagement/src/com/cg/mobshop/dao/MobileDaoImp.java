package com.cg.mobshop.dao;

import java.util.HashMap;
import java.util.List;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public class MobileDaoImp implements MobileDao {

	@Override
	public HashMap<Integer, Mobiles> getMobileList() {
		
		HashMap<Integer, Mobiles> m1=Util.getMobileList();
		return m1;
	}

	@Override
	public HashMap<Integer, Mobiles> deletemobile(int id) {
		HashMap<Integer, Mobiles> hs=Util.remove(id);
		return hs;
		
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<Integer, Mobiles> fetchAll() {
		HashMap<Integer, Mobiles> hs=Util.fetchAllDetails();		
		return hs;
	}

	@Override
	public List<Mobiles> sortByName() {
	
		List<Mobiles> e=Util.sortByName();
		return e;
	}

	@Override
	public List<Mobiles> sortByPrice() {
		
		List<Mobiles> e2=Util.sortByPrice();
		return e2;
	}

	@Override
	public List<Mobiles> sortByQuantity() {

		List<Mobiles> e2=Util.sortByQuantity();
		return e2;
	}

	

}
