package com.cg.mobshop.util;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


import com.cg.mobshop.dto.Mobiles;
public class Util {
	private static HashMap<Integer, Mobiles> mobileEntries =new HashMap<Integer,Mobiles>();
	static {
		
		mobileEntries.put(101, new Mobiles(101,"Sony Xperia",12000,12));	
		mobileEntries.put(102, new Mobiles(102,"Samsung Note",10000,4));
		mobileEntries.put(103, new Mobiles(103,"IPhone",23000,2));	
		mobileEntries.put(104, new Mobiles(104,"Nokia Note 2322",10000,8));	
}
	private static List<Mobiles> list=new ArrayList<Mobiles>();
	static 
	{
		list.add(new Mobiles(101,"Sony Xperia",12000,12));
		list.add(new Mobiles(102,"Samsung Note",10000,4));
		list.add(new Mobiles(103,"IPhone",23000,2));
		list.add(new Mobiles(104,"Nokia Note 2322",10000,8));
		
	}
	public static HashMap<Integer, Mobiles> getMobileList() {
		
		return mobileEntries ;
	}
	public static HashMap<Integer, Mobiles> fetchAllDetails() {
		
		return mobileEntries;
	}
	public static HashMap<Integer, Mobiles> remove(int id)
	{
		 mobileEntries.remove(id);
		 return mobileEntries;
	}
	public static List<Mobiles> sortByName() {
		{
			Collection<Mobiles> v=mobileEntries.values();
			Collections.sort(list, Mobiles.getcompname());
		   return list;

		}
	}
	public static List<Mobiles> sortByPrice() {
		Collections.sort(list);
		   return list;
	}
	public static List<Mobiles> sortByQuantity() {
		Collections.sort(list);
		   return list;
	}
}