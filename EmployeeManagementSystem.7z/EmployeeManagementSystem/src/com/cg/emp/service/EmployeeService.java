package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {

	public HashMap<Integer, Employee> fetchAll();

	public Employee getEmpById(int empId);

	public List<Employee> searchEmpByName();

	public Employee deleteEmp(int empId);

	public Employee updateEmp(int empId, String newName, float newSal);

	public boolean validateEmpName(String name) throws EmployeeException;

	int addEmployee(Integer id,Employee ee) throws EmployeeException;

	public boolean validateEmpId(String eid) throws EmployeeException;
	
}
