package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.dao.EmployeeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeServiceImp implements EmployeeService {
	EmployeeDAO employeeDAO = new EmployeeDAOImpl();

	@Override
	public int addEmployee(Integer id,Employee ee) throws EmployeeException {
		CollectionUtil.addEmp( ee);
		return 0;
	}
	@Override
	public HashMap<Integer, Employee> fetchAll() {
		employeeDAO.fetchAll();
		HashMap<Integer, Employee> ss=employeeDAO.fetchAll();
		return ss;
	}

	@Override
	public Employee getEmpById(int empId) {
	Employee s=employeeDAO.getEmpById(empId);
		return s;
	}

	@Override
	public List<Employee> searchEmpByName() {
	List<Employee> e=	employeeDAO.searchEmpByName();
		return e;
	}

	@Override
	public Employee deleteEmp(int empId) {
		 Employee hs=employeeDAO.deleteEmp(empId);
		return hs;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee n=employeeDAO.updateEmp(empId, newName, newSal);
		return n;
	}

	
	

	@Override
	public boolean validateEmpName(String name) throws EmployeeException {
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{3,15}");
		Matcher m = p.matcher(name);
		if (m.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateEmpId(String empid) throws EmployeeException {
		Pattern p = Pattern.compile("[0-9]{4}");
		Matcher m = p.matcher(empid);
		if (m.matches()) {
			return true;
		} else
			return false;
	}

	
	
	
	

	
}
