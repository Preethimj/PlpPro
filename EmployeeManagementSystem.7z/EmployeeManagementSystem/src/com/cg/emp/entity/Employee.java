package com.cg.emp.entity;

import java.time.LocalDate;
import java.util.Comparator;

public class Employee {
	private int empId;
	private String empname;
	private float empsal;
	private LocalDate empDOJ;

	public Employee(String string, float f, LocalDate localDate) {
		super();
		
	}

	public Employee(int empId, String empname, float empsal, LocalDate empDOJ) {
		super();
		this.empId = empId;
		this.empname = empname;
		this.empsal = empsal;
		this.empDOJ = empDOJ;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public float getEmpsal() {
		return empsal;
	}

	public void setEmpsal(float empsal) {
		this.empsal = empsal;
	}

	public LocalDate getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empname=" + empname + ", empsal=" + empsal + ", empDOJ=" + empDOJ + "]";
	}

	public static Comparator<Employee> getcompname()
	{
		Comparator<Employee> comp=new Comparator<Employee>() {@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return  o1.empname.compareTo(o2.empname);
	}
		};
		return comp;
	}
	

}
