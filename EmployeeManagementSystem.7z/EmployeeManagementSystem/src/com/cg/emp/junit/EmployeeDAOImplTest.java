package com.cg.emp.junit;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.Test;
import com.cg.emp.dao.EmployeeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

class EmployeeDAOImplTest {

	 static EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		
		
		@Test
			public void testAddEmployee() throws EmployeeException
			{
			assertEquals(1002, employeeDAO.addEmployee(1002,new Employee(1002,"preethi",55000.0F,LocalDate.of(2018, Month.JANUARY, 04))));
			} 

	}



