package com.cg.emp.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int addEmployee(Integer id,Employee ee) throws EmployeeException {
		CollectionUtil.addEmp(ee);
		return 0;
	}
	
	@Override
	public HashMap<Integer, Employee> fetchAll(){
			HashMap<Integer, Employee> sa=CollectionUtil.fetchAllEmp();
			return sa;
	}
	
	@Override
	public Employee getEmpById (int empId) {
		Employee e=	CollectionUtil.getEmpById(empId);
		return e;
	}

	@Override
	public List<Employee> searchEmpByName() {
		List<Employee> e=CollectionUtil.SearchByName();
		return e;
	}

	@Override
	public  Employee deleteEmp(int empId) {
		 Employee hs=CollectionUtil.deleteEmp(empId);
		return hs;
	}
	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee f=	CollectionUtil.updateEmp(empId,newName,newSal);
		return f;
	}

	
	
	

}
