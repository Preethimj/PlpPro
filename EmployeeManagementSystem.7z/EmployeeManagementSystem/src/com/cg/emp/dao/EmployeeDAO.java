package com.cg.emp.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeDAO {
	public int addEmployee(Integer id,Employee ee) throws EmployeeException;

	public HashMap<Integer, Employee> fetchAll();

	public Employee getEmpById(int empId);

	public List<Employee> searchEmpByName();

	public Employee deleteEmp(int empId);

	Employee updateEmp(int empId, String newName, float newSal);


}
