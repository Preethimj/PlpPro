package com.cg.emp.ui;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImp;

public class RunMain {
	static Scanner sc = null;
	static EmployeeServiceImp empservice = null;

	public static void main(String[] args) throws EmployeeException {
		sc = new Scanner(System.in);
		empservice = new EmployeeServiceImp();
		int choice = 0;
		while (true) {
			System.out.println("what do u want to do?");
			System.out.println("1:Add emp\t2:Fetch all emp\n");
			System.out.println("3:Delete emp\t4:search emp by id\n");
			System.out.println("5:search emp by name\t6:update emp\n");
			System.out.println("7.EXIT\n");
			System.out.println("enter your choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				addEmployee();

				break;
			case 2:
				fetchAllEmp();
				break;
			case 3:
				getEmployeeById();
				break;
			case 4:searchByName();
			break;
			case 5:deleteEmp();
			break;
			case 6:updateEmp();
			break;
			default:

			}
		}
	}

	private static void updateEmp() {
	System.out.println("enter the id");
	int id2 = sc.nextInt();
	Employee eo = empservice.getEmpById(id2);
	/*eo.setEmpname("ashka");
	eo.setEmpsal(80000);
	eo.setEmpId(10000);
	System.out.println(eo);*/
	System.out.println("enter the name to be updated");
	String i1=sc.next();
	System.out.println("enter the salary to be updated");
	float i2=sc.nextInt();
	eo.setEmpsal(i2);
	eo.setEmpname(i1);
	System.out.println(eo);
	}

	private static void searchByName() {
		
		
	List<Employee> l=empservice.searchEmpByName();
	
System.out.println("sorting of employee by name");
		Iterator<Employee> i=l.iterator();
		while(i.hasNext())
			{
			System.out.println(i.next());
			}
	
		 }
		
	

	private static void deleteEmp() {
		System.out.println("enter id");
		int id1 = sc.nextInt();
		Employee ed = empservice.deleteEmp(id1);
		HashMap<Integer, Employee> ts = empservice.fetchAll();
		Iterator it = ts.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());
		}

		}
	

	private static void getEmployeeById() {
		System.out.println("enter id");
		int id = sc.nextInt();
		Employee e = empservice.getEmpById(id);
		System.out.println(e);
		try {
			if (e==null) {
				throw new EmployeeException(null);
				
			}
		} catch (EmployeeException ms) {
			System.out.println("invalid id");
		}

	}

	private static void fetchAllEmp() {
		HashMap<Integer, Employee> ts = empservice.fetchAll();
		Iterator it = ts.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());

		}

	}

	private static void addEmployee() {
			System.out.println("enter empid:");
			String eid = sc.next();
			try {
				if (empservice.validateEmpId(eid)) {

					while (true) {
						System.out.println("enter the employee name :");
						String name = sc.next();
						try {
							if (empservice.validateEmpName(name)) {

								System.out.println("enter the employee salary:");
								float sal = sc.nextFloat();
								Employee employee = new Employee(Integer.parseInt(eid), name, sal, LocalDate.now());
								int empId = empservice.addEmployee(Integer.parseInt(eid),employee);
								System.out.println("employee added" + empId);
								break;
							}
						} catch (Exception e) {

						}
					}
				}
			} catch (Exception e) {

			}
		

	}
}
